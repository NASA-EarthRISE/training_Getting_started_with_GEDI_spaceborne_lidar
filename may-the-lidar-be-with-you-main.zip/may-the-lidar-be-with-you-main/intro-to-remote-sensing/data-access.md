---
layout: page
title: Data Access
parent: Introduction to Remote Sensing
nav_order: 2
---

# Data Access
Brief description, lesson objectives. 

## Earth Explorer
Overview and screenshots of downloading data from Earth Explorer.

## Copernicus Open Access Hub
Overview and screenshots of downloading data from the Copernicus Open Access Hub.
